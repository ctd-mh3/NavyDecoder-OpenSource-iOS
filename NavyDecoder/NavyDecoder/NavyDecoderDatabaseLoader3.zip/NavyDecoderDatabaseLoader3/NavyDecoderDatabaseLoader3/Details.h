//
//  Details.h
//  NavyDecoderDatabaseLoader
//
//  Created by michael on 10/27/12.
//  Copyright (c) 2012 Crash Test Dummy Limited. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class Item;

@interface Details : NSManagedObject

@property (nonatomic, retain) NSString * codeSource;
@property (nonatomic, retain) NSString * codeValue;
@property (nonatomic, retain) Item *itemKey;

@end
