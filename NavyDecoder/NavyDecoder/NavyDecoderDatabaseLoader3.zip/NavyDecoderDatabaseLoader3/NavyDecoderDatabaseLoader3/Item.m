//
//  Item.m
//  NavyDecoderDatabaseLoader
//
//  Created by michael on 10/27/12.
//  Copyright (c) 2012 Crash Test Dummy Limited. All rights reserved.
//

#import "Item.h"
#import "Category.h"
#import "Details.h"


@implementation Item

@dynamic codeKey;
@dynamic itemDetails;
@dynamic categorySource;

@end
