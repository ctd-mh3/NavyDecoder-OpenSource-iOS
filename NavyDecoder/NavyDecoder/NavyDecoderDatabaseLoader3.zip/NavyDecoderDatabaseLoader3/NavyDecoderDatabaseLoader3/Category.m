//
//  Category.m
//  NavyDecoderDatabaseLoader
//
//  Created by michael on 10/27/12.
//  Copyright (c) 2012 Crash Test Dummy Limited. All rights reserved.
//

#import "Category.h"
#import "Item.h"


@implementation Category

@dynamic categoryTitle;
@dynamic categoryItems;

@end
