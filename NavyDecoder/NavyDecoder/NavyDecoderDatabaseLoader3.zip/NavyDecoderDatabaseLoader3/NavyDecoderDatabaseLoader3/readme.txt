See http://www.raywenderlich.com/12170/core-data-tutorial-how-to-preloadimport-existing-data-updated on process to general core data from json input.

Now that this project is setup, here are the steps needed to update the iOS Navy Decoder Core Data:
- Run convertSqlScriptsToJson.pl script in Android app's database directory
- Copy resulting new DecoderData.json to this XCode project
- Execute this project
- Right click on the NavyDecoderDatabaseLoader product in "Products' list in XCode and select "Show in Finder"
- Copy the NavyDecoderDatabaseLoader.sqlite file in the Finder window that opens
- Open NavyDecoder project in XCode
- Right click on the DecoderData.sqlite file and select "Show in Finder"
- Paste the NavyDecoderDatabaseLoader.sqlite into the Finder folder that contains DecoderData.sqlite
- Delete the DecoderData.sqlite file and rename the NavyDecoderDatabaseLoader.sqlite to DecoderData.sqlite

