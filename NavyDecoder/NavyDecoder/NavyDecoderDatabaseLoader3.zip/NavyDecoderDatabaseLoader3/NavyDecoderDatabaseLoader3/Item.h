//
//  Item.h
//  NavyDecoderDatabaseLoader
//
//  Created by michael on 10/27/12.
//  Copyright (c) 2012 Crash Test Dummy Limited. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class Category, Details;

@interface Item : NSManagedObject

@property (nonatomic, retain) NSString * codeKey;
@property (nonatomic, retain) Details *itemDetails;
@property (nonatomic, retain) Category *categorySource;

@end
