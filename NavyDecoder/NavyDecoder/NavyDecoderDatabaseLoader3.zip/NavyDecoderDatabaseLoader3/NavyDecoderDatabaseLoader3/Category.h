//
//  Category.h
//  NavyDecoderDatabaseLoader
//
//  Created by michael on 10/27/12.
//  Copyright (c) 2012 Crash Test Dummy Limited. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class Item;

@interface Category : NSManagedObject

@property (nonatomic, retain) NSString * categoryTitle;
@property (nonatomic, retain) NSSet *categoryItems;
@end

@interface Category (CoreDataGeneratedAccessors)

- (void)addCategoryItemsObject:(Item *)value;
- (void)removeCategoryItemsObject:(Item *)value;
- (void)addCategoryItems:(NSSet *)values;
- (void)removeCategoryItems:(NSSet *)values;

@end
