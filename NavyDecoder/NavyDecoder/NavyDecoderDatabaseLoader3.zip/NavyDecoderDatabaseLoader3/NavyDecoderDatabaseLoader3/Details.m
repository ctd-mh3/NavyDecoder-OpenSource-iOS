//
//  Details.m
//  NavyDecoderDatabaseLoader
//
//  Created by michael on 10/27/12.
//  Copyright (c) 2012 Crash Test Dummy Limited. All rights reserved.
//

#import "Details.h"
#import "Item.h"


@implementation Details

@dynamic codeSource;
@dynamic codeValue;
@dynamic itemKey;

@end
